import java.util.Scanner;

public class MovieTickets{
	public static void main (String [] args){
		Scanner input = new Scanner(System.in);

		System.out.println("What time is your showing?");
		int time = input.nextInt();	


		double regular = 0;
		double child = 0;
		double senior = 0;
		int totalParty = 1;
		int totalChild = 0;
		int totalRegular = 0;
		int totalSenior = 0;
		double totalCost = 0;

		while(time < 1700 && time > 0){
			System.out.println("What is the age of party member:"+totalParty);
			System.out.println("(any negative number to exit)");
			int age = input.nextInt();
				if(age <= 10 && age > 0 ){
					totalParty++;
					totalChild++;
				}
				else if(age >=10 && age <= 65){
					totalCost = totalCost + 8.00;
					regular = regular + 8.00;
					totalParty++;
					totalRegular++;

				}
				else if (age >= 65){
					totalCost = totalCost + 6.50;
					senior = senior + 6.50;
					totalParty++;
					totalSenior++;
				}
				else{
					break;

				}
			}



			
		while(time >= 1700 || time == 0 ){
			System.out.println("What is the age of party member:"+totalParty);
			System.out.println("(any negative number to exit)");
			int age = input.nextInt();
				if(age <= 10 && age > 0 ){
					totalCost = totalCost + 4.00; 
					child = child + 4.00;
					totalParty++;
					totalChild++;
				}
				else if(age >=10 && age <= 65){
					totalCost = totalCost + 10.50;
					regular = regular + 10.50;
					totalParty++;
					totalRegular++;

				}
				else if (age >= 65){
					totalCost = totalCost + 8.00;
					senior = senior + 8.00;
					totalParty++;
					totalSenior++;
				}
				else{ 
					break;

				}

			}	

		System.out.println("Order summary");
		if (time < 1700 || time > 0){
			System.out.println("Evening Rates");
				if (regular > 0){
				System.out.println("Regular = 10.50 X "+totalRegular+"="+regular);

			}
			if (senior > 0){
				System.out.println("Senior = 8.00 X "+totalSenior+"="+senior);

			}
			if (totalChild > 0){
				System.out.println("Child = 4.00 X "+totalChild+"="+child);
			}

			System.out.println("total = "+totalCost);
			}

		else if (time >= 1700 || time == 0 ){
			System.out.println("Matinee");
			
			if (regular > 0){
				System.out.println("Regular = 8.00 X "+totalRegular+"="+regular);

			}
			if (senior > 0){
				System.out.println("Senior = 6.50 X "+totalSenior+"="+senior);

			}
			if (child > 0){
				System.out.println("Child = 0 X "+totalChild+"="+child);

				System.out.println("total = "+totalCost);
			}
		}
	}
}