public class pot {
	
	private boolean boilerFull;
	private boolean potOn;
	
	
	public void potEmpty(){
		boilerFull = false;
	}
		
		
	
	
	
	public void boilerNotEmpty(){
		boilerFull = true;
	}
	public void putPotOn(){
		potOn = true ;
	}
	public void takePotOff(){
		potOn = false;
	}
	public boolean checkBoiler(){
		return boilerFull;
	}
	public boolean checkPotOn(){
		return potOn;
	}
	
		
	
}
