
public class Button{
	public static void main(String[]args){

		//test case 1
		
		done coffee = new done ("Strong");
		//you must of course fill the water then return the pot before you start the boil 
		coffee.fillwater(7);
		coffee.returnpot();
		coffee.startboil();
		// with a single serve boiler you press boil multiple times 
		coffee.onecup();
		coffee.onecup();
		coffee.liftpot();
		coffee.onecup();
		coffee.returnpot();
		coffee.onecup();
		System.out.println();

		//test case 2
		done coffee1 = new done("Medium");
		coffee1.liftpot();
		// you can fill loader but not start boil without pot
		coffee1.startboil();
		coffee1.fillwater(4);
		coffee1.returnpot();
		coffee1.startboil();
		coffee1.onecup();
		//depending on the machine one or the other can be used by commeting out one cup if a single serve or full pot if its a full pot serve.
		//neithe will work once empty
		coffee.fullpot();
		//physical commands with no monitering(such as loading the grinds)will have a static method checks
		/*checkrecepticle();
		loadrecepticle();
		checkrecepticle();
		emptyrecepticle();
		checkrecepticle();
*/
		System.out.println();
		//use case 1
		done coffee2 = new done("medium");
		coffee2.returnpot();
		coffee2.fillwater(12);
		coffee.startboil();
		
		System.out.println();
		done coffee3 = new done("light");
		coffee3.returnpot();
		coffee3.fillwater(12);
		coffee3.startboil();
		coffee3.liftpot();
		coffee3.returnpot();
		
		System.out.println();
		done coffee4 = new done ("strong");
		coffee4.liftpot();
		coffee4.returnpot();
		coffee4.startboil();
		
		
		

	}

}
