
//
public class Boiler extends pot implements Pressure{
	private boolean boil;
	private int water;
	private String x;
	
	public String tostring(String x){
		this.x = x;
		return x;
	}
	
	public void startboil(){
		if( checkPotOn() == true ){
			boil = true;
			boilerNotEmpty();
			System.out.println("The Boil process has started");
		}
		else{
			System.out.println("Please return the pot before starting boil");
		
		}
	}
	public void endboil(int x){
		boil = false;
		System.out.println("Boiling has ended");
		
	}
	public boolean checkBoil(){
		return boil;
	}
	public void fillwater(int x){
		water = water + x;
		boilerNotEmpty();
		System.out.println("The machine has been filled with "+water+" Cups worth of water.");
		
	}
	public int checkWater(){
		return water;
	}
	public int waterleft(){
		water--;
		return water;
	}
	public int fullpour(){
		water = 0;
		return water;
	}
	public void onecup(){
		if(checkWater() >= 1 && checkBoil()== true && checkPotOn()){
		System.out.println("A cups worth of"+toString()+ "coffee has been brewed. There are "+waterleft()+" cups worth left in Boiler");
		}
		else{System.out.println("There is no coffee to pour, Please check that the boiler has been activated.");
		
		}
	}
		public void fullpot(){
			if(checkWater() >= 1 && checkBoil()== true){
				
			
			System.out.println("A Pots worth of"+toString()+" coffee has been created. There is "+fullpour()+" cups left in the boiler.");
			}
			else{System.out.println("There is no coffee to pour, Please check that the boiler has been activated.");
			
			}
	}
	
	
}
