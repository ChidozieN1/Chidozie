
public class done extends plate{
	
	
	done(String x){
		
	}
	
	static boolean recepticle;
	
	
	
	public static void loadrecepticle(){
		recepticle = true;
	}
	public static boolean getrecepticle(){
		return recepticle;
	}
	public static void emptyrecepticle(){
		recepticle = false;
	}
	
	public static void checkrecepticle(){
		if(getrecepticle()== true){
			System.out.println("The recepticle is full");
		}
			else{
			System.out.println("Recepticle is empty");	
		
			}
		}
	
}
