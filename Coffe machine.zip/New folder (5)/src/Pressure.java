public interface Pressure {
	
	
	
	public String strong();
	
	public String medium();
	
	
	public String light(){
		return "light";
	}
}
