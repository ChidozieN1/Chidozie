public interface Flavors{
	public class String extra(){
		System.out.println("Default Black");
		return 
	}

}
