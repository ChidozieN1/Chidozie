
public class plate extends Boiler{
	private boolean heat;
	
	
	
	public void potishot(){
		if (checkPotOn() == true && checkBoiler() == true){
			heat = true;
		}
		
	}
	
	public void liftpot(){
		heat = false;
		takePotOff();
		System.out.println("The Pot has been lifted");
	}
	public void returnpot(){
		if(checkBoiler() == true){
			System.out.println("Pot has been returned and still cointains liquid/Is able to start the brewing process.");
			System.out.println("Plate has been turned on");
			putPotOn();
			potishot();
		}
		
	}
	
}
